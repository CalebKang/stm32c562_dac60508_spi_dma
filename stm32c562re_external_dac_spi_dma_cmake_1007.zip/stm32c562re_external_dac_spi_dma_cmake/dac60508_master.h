/*
 * dac60508_master.h
 *
 *  Created on: Oct 6, 2026
 *      Author: calebkang
 */

#ifndef STM32C562RE_EXTERNAL_DAC_SPI_DMA_CMAKE_DAC60508_MASTER_H_
#define STM32C562RE_EXTERNAL_DAC_SPI_DMA_CMAKE_DAC60508_MASTER_H_

#include <stdint.h>

#define DAC60508_REG_NOP 0x00U
#define DAC60508_REG_CONFIG 0x03U
#define DAC60508_REG_GAIN 0x04U
#define DAC60508_REG_TRIGGER 0x05U
#define DAC60508_REG_DAC0 0x08U
#define DAC60508_CONFIG_CRC_EN 0x0800U
/* REFDIV-EN: VREF/2. Needed with the 2.5 V internal reference when VDD <= 3.3 V,
 * otherwise REF-ALM shuts the reference buffer down and all outputs stay at 0 V. */
#define DAC60508_GAIN_REFDIV_EN 0x0100U
#define DAC60508_GAIN_BUFF_ALL_X2 0x00FFU
#define DAC60508_TRIGGER_SOFT_RESET 0x000AU
#define DAC60508_CHANNEL_COUNT 8U
#define DAC60508_MAX_CODE 0x0FFFU

/* CRC-8-ATM/HEC: polynomial x^8+x^2+x+1, init 0, no reflection/xorout. */
static inline uint8_t dac60508_crc8(const uint8_t *data, uint32_t length)
{
  uint8_t crc = 0U;
  for (uint32_t i = 0U; i < length; ++i)
  {
    crc ^= data[i];
    for (uint32_t bit = 0U; bit < 8U; ++bit)
    {
      crc = (crc & 0x80U) != 0U ? (uint8_t)((crc << 1) ^ 0x07U)
                                : (uint8_t)(crc << 1);
    }
  }
  return crc;
}

extern void dac60508_master_init(void);
extern void dac60508_master_set_channel(uint8_t channel, uint16_t code);

#endif /* STM32C562RE_EXTERNAL_DAC_SPI_DMA_CMAKE_DAC60508_MASTER_H_ */

/*
 * dac60508_master.c
 *
 *  Created on: Oct 6, 2026
 *      Author: calebkang
 */
#include "main.h"

#define DAC60508_CS_PORT  GPIOA
#define DAC60508_CS_PIN   LL_GPIO_PIN_4

/* One frame takes ~2 us at 18 MHz SCK; anything near this is a stuck transfer. */
#define DAC60508_XFER_TIMEOUT_MS  2U

static uint8_t tx_frame[4]; /* DMA source must remain valid until EOT. */
static volatile uint8_t dma_complete = 1U;
static volatile uint8_t dma_error;
static uint8_t crc_enabled;

/* Stop the SPI/DMA transfer, release CS and report it as finished with an error. */
static void dac60508_abort_transfer(void)
{
  /* LPDMA_CxCR.RESET only takes effect on a suspended or disabled channel. */
  if (LL_DMA_IsEnabledChannel(LPDMA2_CH0) != 0U)
  {
    LL_DMA_SuspendChannel(LPDMA2_CH0);
    while ((LL_DMA_IsActiveFlag_SUSP(LPDMA2_CH0) == 0U) && (LL_DMA_IsActiveFlag_IDLE(LPDMA2_CH0) == 0U))
    {
    }
  }
  LL_DMA_ResetChannel(LPDMA2_CH0);
  LL_DMA_ClearFlag(LPDMA2_CH0, LL_DMA_FLAG_ALL);

  LL_SPI_Disable(SPI1);
  LL_SPI_DisableIT(SPI1, (LL_SPI_IT_EOT | LL_SPI_IT_OVR | LL_SPI_IT_UDR));
  LL_SPI_DisableDMAReq_TX(SPI1);
  LL_GPIO_SetOutputPin(DAC60508_CS_PORT, DAC60508_CS_PIN);
  dma_error = 1;
  dma_complete = 1;
}

void LPDMA2_CH0_IRQHandler(void)
{
  DMA_Channel_TypeDef *channel;
  DMA_TypeDef *instance;
  uint32_t    flags;
  uint32_t    its;
  uint32_t    dma_channel;

  channel      = LPDMA2_CH0;
  instance     = LL_DMA_GET_INSTANCE(LPDMA2_CH0);
  dma_channel  = LL_DMA_GET_CHANNEL_IDX(LPDMA2_CH0);
  its          = LL_DMA_READ_REG((LPDMA2_CH0), CCR);

  /* Check DMA channel active interrupts */
  if (LL_DMA_IsActiveFlag_MIS(instance, dma_channel) == 0U)
  {
    return; /* the global interrupt flag for the current channel is down , nothing to do */
  }

  flags = LL_DMA_READ_REG((channel), CSR);

  /* Transfer Complete Interrupt management */
  if (STM32_READ_BIT((flags & its), LL_DMA_FLAG_TC) != 0U)
  {
    LL_DMA_ClearFlag_TC(channel);
    return;
  }

  /* Error Interrupt management */
  LL_DMA_ClearFlag(channel, LL_DMA_FLAG_ALL);

  /* Check error flags */
  if (((flags & its) & (LL_DMA_FLAG_DTE | LL_DMA_FLAG_USE)) != 0U)
  {
    LL_DMA_ResetChannel(channel);

    LL_DMA_DisableIT(channel, LL_DMA_IT_ALL);
  }

  /* The SPI never reaches EOT without its data: end the frame here. */
  dac60508_abort_transfer();
}


void SPI1_IRQHandler(void)
{
  uint32_t flag_status   = LL_SPI_READ_REG(SPI1, IER);
  uint32_t pending_flags = flag_status & LL_SPI_READ_REG(SPI1, SR);

  /* SPI End Of Transfer */
  if ((pending_flags & SPI_SR_EOT) != 0U)
  {
    LL_SPI_ClearFlag(SPI1, (LL_SPI_FLAG_EOT | LL_SPI_FLAG_TXTF));

    LL_SPI_DisableIT_EOT(SPI1);

    /* Reset the Tx/Rx DMA */
    LL_SPI_Disable(SPI1);
    LL_SPI_DisableDMAReq_TX(SPI1);
    LL_GPIO_SetOutputPin(DAC60508_CS_PORT, DAC60508_CS_PIN);
    dma_complete = 1;
    return;
  }

  if ((pending_flags & SPI_SR_OVR) != 0UL)
  {
    LL_SPI_ClearFlag_OVR(SPI1);
  }

  if ((pending_flags & SPI_SR_UDR) != 0UL)
  {
    LL_SPI_ClearFlag_UDR(SPI1);
  }

  /* Disable SPI peripheral and all interrupts */
  dac60508_abort_transfer();
}


/* Wait until the frame on the bus is finished (CS released). */
static void dac60508_wait(void)
{
  uint32_t start = HAL_GetTick();

  while (dma_complete == 0U)
  {
    if ((HAL_GetTick() - start) > DAC60508_XFER_TIMEOUT_MS)
    {
      dac60508_abort_transfer();
    }
  }
}


/* Send one write frame: 24 bits, or 32 bits with the CRC byte when with_crc != 0.
 * Returns once the frame is started; the next call waits for it to finish. */
static void dac60508_write(uint8_t reg, uint16_t data, uint8_t with_crc)
{
  uint32_t size = 3U;

  dac60508_wait(); /* tx_frame is still the DMA source of the previous frame */

  tx_frame[0] = reg & 0x0FU; /* RW=0, reserved bits=0. */
  tx_frame[1] = (uint8_t)(data >> 8);
  tx_frame[2] = (uint8_t)data;
  if (with_crc != 0U)
  {
    tx_frame[3] = dac60508_crc8(tx_frame, 3U);
    size = 4U;
  }

  /* Set the number of data at current transfer */
  LL_SPI_SetTransferSize(SPI1, size);

  /* Enable interrupts */
  LL_SPI_EnableIT(SPI1, (LL_SPI_IT_EOT | LL_SPI_IT_OVR | LL_SPI_IT_UDR));

  /* Enable the Tx DMA Stream/Channel  */
  LL_DMA_ConfigAddresses(LPDMA2_CH0, (uint32_t)tx_frame, LL_SPI_DMA_GetTxRegAddr(SPI1));
  LL_DMA_SetBlkDataLength(LPDMA2_CH0, size);
  LL_DMA_ClearFlag(LPDMA2_CH0, LL_DMA_FLAG_ALL);
  LL_DMA_EnableIT(LPDMA2_CH0, (LL_DMA_IT_TC | LL_DMA_IT_DTE | LL_DMA_IT_USE));
  LL_DMA_EnableChannel(LPDMA2_CH0);

  LL_GPIO_ResetOutputPin(DAC60508_CS_PORT, DAC60508_CS_PIN);

  /* Enable the Tx/Rx DMA */
  LL_SPI_EnableDMAReq_TX(SPI1);

  /* Enable SPI */
  dma_error = 0;
  dma_complete = 0;
  LL_SPI_Enable(SPI1);

  LL_SPI_StartMasterTransfer(SPI1);
}


void dac60508_master_init(void)
{
  /* SPE is cleared after every frame. Keep SCK driven at its idle level meanwhile
   * instead of floating (RM0522 SPI_CFG2.AFCNTR, writable only while SPE = 0). */
  LL_SPI_EnableGPIOControl(SPI1);

  /* DAC power-on reset: communication is valid 250 us after VDD/VIO are up. */
  HAL_Delay(1);

  /* The DAC is not reset together with the MCU and may still be in CRC mode.
   * 24-bit soft reset: accepted with CRC off, ignored (too short) with CRC on.
   * 32-bit soft reset: accepted with CRC on; with CRC off only its last 24 bits
   * are used, which decode as a write to the NOP register.
   * A soft reset is a POR event: wait 250 us before the next access. */
  dac60508_write(DAC60508_REG_TRIGGER, DAC60508_TRIGGER_SOFT_RESET, 0U);
  dac60508_wait();
  HAL_Delay(1);
  dac60508_write(DAC60508_REG_TRIGGER, DAC60508_TRIGGER_SOFT_RESET, 1U);
  dac60508_wait();
  HAL_Delay(1);

  /* VREF/2 = 1.25 V and buffer gain x2 on all channels: 0..2.5 V full scale. */
  dac60508_write(DAC60508_REG_GAIN, DAC60508_GAIN_REFDIV_EN | DAC60508_GAIN_BUFF_ALL_X2, 0U);

  /* From here on every frame is 32 bits with the CRC byte appended. */
  dac60508_write(DAC60508_REG_CONFIG, DAC60508_CONFIG_CRC_EN, 0U);
  dac60508_wait();
  crc_enabled = 1U;
}


void dac60508_master_set_channel(uint8_t channel, uint16_t code)
{
  if (channel >= DAC60508_CHANNEL_COUNT)
  {
    return;
  }

  if (code > DAC60508_MAX_CODE)
  {
    code = DAC60508_MAX_CODE;
  }

  /* 12-bit data is MSB aligned: { DATA[11:0], x, x, x, x } */
  dac60508_write((uint8_t)(DAC60508_REG_DAC0 + channel), (uint16_t)(code << 4), crc_enabled);
}
